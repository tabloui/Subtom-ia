# Subtom IA — notas de refactorización

## Cambios incluidos

- La generación de imágenes requiere intención textual explícita (`!image`, `dibuja`, `genera una imagen`, etc.). Los adjuntos por sí solos no disparan generación.
- Los adjuntos `.py`, `.txt`, Markdown, JSON, YAML, HTML, SQL y otros formatos de texto admitidos se leen antes de la primera llamada al modelo mediante `file_read`; los PDF se procesan mediante `file_read_pdf`. La lectura está limitada por archivo y por turno. Los archivos con nombres típicos de credenciales (`.env`, `secrets`, `credentials`, claves privadas) se omiten y los patrones comunes de secretos en otros textos se redactan antes de enviarlos al proveedor.
- Se añadieron `file_create_zip` y `deploy_temp_website` al catálogo de herramientas y a sus handlers.
- El conector pasa al siguiente proveedor cuando recibe HTTP 429 o 5xx, respetando cancelaciones y registrando el slot fallido.
- E2B intenta importar `AsyncSandbox` desde `e2b_code_interpreter` y admite el SDK base `e2b` como alternativa. El despliegue web crea `index.html`, inicia el servidor HTTP en el puerto 8080, comprueba que responde y devuelve la URL pública.
- `motor.py` se redujo a caché LRU/TTL, métricas acotadas y una fachada de compatibilidad. Se corrigió la invalidación por prefijo.
- El historial se recorta conservando el prompt de sistema y grupos completos de llamadas/resultados de herramientas. También se garantiza que el mensaje actual llegue al modelo aunque PostgreSQL no esté configurado o no devuelva historial.
- El bucle de verificación devuelve stdout y stderr (incluido el traceback) al modelo y respeta `MAX_FIX_ATTEMPTS` y el límite de errores repetidos. La auto-instalación se limita a una allowlist de paquetes Python conocidos; no ejecuta `pip`/`npm` con nombres arbitrarios obtenidos de un traceback.
- `github_upload_project` resuelve rutas desde la raíz y subcarpetas del workspace, rechaza destinos inseguros y reporta rutas resueltas y archivos omitidos.
- La creación de ZIP evita duplicados, auto-inclusión y enlaces simbólicos que salgan del workspace.

## Configuración relevante

- `E2B_API_KEY`: necesaria para ejecutar o desplegar en E2B.
- `MAX_FIX_ATTEMPTS`: número máximo de correcciones automáticas (por defecto, 8; limitado a 1–30 por configuración).
- `AI_MAX_CONTEXT_CHARS`, `AI_MAX_CONTEXT_MESSAGES` y `AI_MAX_AUTO_READ_CHARS`: límites de contexto configurables.
- `E2B_SANDBOX_TIMEOUT_SECONDS` no está habilitada en este refactor: el sandbox conserva un límite configurado de 3.600 segundos.

## Disponibilidad de webs E2B

La URL es temporal y deja de funcionar al apagar o expirar el sandbox. El proyecto configura actualmente un máximo de 3.600 segundos desde la creación del sandbox (una hora); el tiempo restante después del despliegue puede ser menor. Por tanto, el texto de “máximo 7 días” describe solo un techo superior y **no** garantiza siete días de disponibilidad. Los límites reales también dependen del plan y de las políticas de E2B.

El servidor HTTP publica el HTML del sandbox en el puerto 8080. No incluyas secretos, tokens ni información privada en el HTML.

## Verificación realizada

- `compileall`/compilación sintáctica de todos los módulos Python.
- Suite `python test_code_loop.py`: los 9 tests pasan, incluyendo sintaxis, runtime, errores repetidos, límite de intentos, proceso persistente, ausencia de variables de entorno, pytest, imports locales y degradación sin sandbox.
- Pruebas de regresión aisladas: intención de imagen, autolectura de adjuntos, ZIP, resolución GitHub en subcarpetas, despliegue web con SDK E2B simulado, recorte de contexto, invalidación de caché y fallback HTTP 503.
- Los 81 esquemas de herramientas tienen handler asociado.

No se han ejecutado llamadas reales a Discord, PostgreSQL, GitHub ni E2B: el entorno de validación no contiene sus credenciales. Las pruebas de despliegue E2B y fallback GitHub/IA se realizaron con dobles simulados, sin llamadas externas.
