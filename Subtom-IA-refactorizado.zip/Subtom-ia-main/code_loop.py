"""
Bucle autónomo de verificación y corrección de código.

Flujo (lo gestiona ai.py, este módulo pone las piezas):

    el modelo escribe/edita archivos
            │
            ▼
    ┌─► COMPUERTA: el modelo quiere terminar → se prueba SIEMPRE el código
    │       1. chequeo estático local (sintaxis, JSON)
    │       2. sube los archivos al sandbox
    │       3. instala dependencias, ejecuta tests / el programa
    │       │
    │       ├─ OK ────────────► se rompe el bucle y se responde
    │       └─ FALLA ─► el error vuelve al modelo como mensaje
    │                    │  el modelo lo corrige (quita / agrega / cambia)
    └────────────────────┘

Salvaguardas para que el bucle SIEMPRE termine:
  - máximo de intentos (MAX_FIX_ATTEMPTS)
  - mismo error 3 veces seguidas → se rinde y lo dice honestamente
  - errores de entorno (falta API key, sin DB...) no son bugs → no se persiguen
"""
from __future__ import annotations

import ast
import hashlib
import json
import re
import shlex
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable, Protocol

REMOTE_ROOT = "/home/user/project"

VERIFIABLE_EXT = {".py", ".js", ".mjs", ".json"}
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "generated", ".pytest_cache"}
MAX_SYNC_FILES = 150
MAX_SYNC_BYTES = 512 * 1024
TAIL_CHARS = 12000
SAME_ERROR_LIMIT = 3

ENTRY_NAMES = {"main", "app", "run", "bot", "server", "index", "cli", "__main__"}

# Allowlist conservadora: nunca instalar con pip/npm un nombre de módulo arbitrario
# extraído de un traceback (podría ser un typo, un módulo local o un paquete malicioso).
PIP_NAMES = {
    "cv2": "opencv-python-headless",
    "PIL": "pillow",
    "yaml": "pyyaml",
    "bs4": "beautifulsoup4",
    "sklearn": "scikit-learn",
    "dotenv": "python-dotenv",
    "discord": "discord.py",
    "dateutil": "python-dateutil",
    "serial": "pyserial",
    "jwt": "pyjwt",
    "requests": "requests",
    "aiohttp": "aiohttp",
    "numpy": "numpy",
    "pandas": "pandas",
    "matplotlib": "matplotlib",
    "flask": "flask",
    "fastapi": "fastapi",
    "uvicorn": "uvicorn",
    "pydantic": "pydantic",
    "sqlalchemy": "sqlalchemy",
    "httpx": "httpx",
    "openai": "openai",
    "anthropic": "anthropic",
    "redis": "redis",
    "pytest": "pytest",
    "lxml": "lxml",
    "openpyxl": "openpyxl",
    "docx": "python-docx",
    "aiofiles": "aiofiles",
}

# Errores que dependen del entorno del sandbox, no del código.
_ENV_ERROR = re.compile(
    r"(Falta la variable|KeyError: ['\"][A-Z][A-Z0-9_]{2,}['\"]|"
    r"ConnectionRefusedError|Connection refused|could not connect to server|"
    r"Name or service not known|getaddrinfo failed|"
    r"(api[_ ]?key|token|secret|credentials?)\b.{0,40}\b(missing|not set|required|invalid|falta|no configurad))",
    re.IGNORECASE,
)


# ======================================================================
# Ejecutor (abstracción para poder probar sin E2B)
# ======================================================================

class Executor(Protocol):
    async def put_files(self, files: dict[str, bytes]) -> None: ...
    async def run(self, command: str, timeout: float) -> dict[str, Any]: ...


class SandboxExecutor:
    """Ejecutor real: el sandbox E2B de sandbox.py."""

    def __init__(self, sb: Any, remote_root: str = REMOTE_ROOT) -> None:
        self.sb = sb
        self.remote_root = remote_root

    async def put_files(self, files: dict[str, bytes]) -> None:
        # Empezar limpio en cada verificación: evita restos de intentos anteriores.
        await self.sb.run_shell(
            f"rm -rf {shlex.quote(self.remote_root)} && mkdir -p {shlex.quote(self.remote_root)}",
            allow_dangerous=True,
        )
        res = await self.sb.put_files(
            {f"{self.remote_root}/{rel}": data for rel, data in files.items()}
        )
        if not res.get("ok"):
            raise RuntimeError(f"No se pudieron subir los archivos al sandbox: {res.get('error')}")

    async def run(self, command: str, timeout: float) -> dict[str, Any]:
        return await self.sb.run_shell(command, timeout=timeout)


# ======================================================================
# Resultados
# ======================================================================

@dataclass
class Check:
    name: str
    ok: bool
    command: str = ""
    returncode: int = 0
    stdout: str = ""
    stderr: str = ""
    inconclusive: bool = False
    note: str = ""


@dataclass
class VerifyReport:
    checks: list[Check] = field(default_factory=list)
    sandbox_used: bool = False
    notes: list[str] = field(default_factory=list)
    reused: bool = False

    @property
    def failed(self) -> Check | None:
        for c in self.checks:
            if not c.ok and not c.inconclusive:
                return c
        return None

    @property
    def status(self) -> str:
        if self.failed:
            return "fail"
        if any(c.inconclusive for c in self.checks) or not self.sandbox_used:
            return "inconclusive"
        return "ok"

    @property
    def signature(self) -> str:
        c = self.failed
        if not c:
            return ""
        combined = "\n".join(part for part in (c.stdout, c.stderr) if part)
        lines = [l.strip() for l in combined.splitlines() if l.strip()]
        last = lines[-1] if lines else ""
        last = re.sub(r"0x[0-9a-fA-F]+|\d+(\.\d+)?s\b", "", last)
        return hashlib.blake2b(f"{c.name}|{last}".encode("utf-8", "ignore"), digest_size=6).hexdigest()

    def feedback(self, attempt: int, max_attempts: int, repeated: int) -> str:
        c = self.failed
        assert c is not None
        # Conserva stdout y stderr; el traceback suele estar en stderr, pero
        # algunas herramientas lo escriben en stdout.
        combined_output = "\n".join(part for part in (c.stdout, c.stderr) if part)
        body = _tail(combined_output or "(sin salida)")
        parts = [
            f"🔁 VERIFICACIÓN AUTOMÁTICA — intento {attempt}/{max_attempts}: FALLÓ",
            f"Comprobación: {c.name}",
        ]
        if c.command:
            parts.append(f"Comando: {c.command}")
        parts.append(f"Código de salida: {c.returncode}")
        if self.notes:
            parts.append("Notas: " + " | ".join(self.notes))
        parts += ["--- error ---", body, "--- fin del error ---"]
        if self.reused:
            parts.append(
                "⚠️ No modificaste ningún archivo desde el último intento, "
                "así que el resultado es idéntico."
            )
        elif repeated >= 2:
            parts.append(
                f"⚠️ Es el MISMO error por {repeated}ª vez: tu arreglo anterior no sirvió. "
                "Cambia de enfoque y relee el archivo con file_read antes de editar."
            )
        parts.append(
            "INSTRUCCIONES: localiza la causa real en el código y corrígela con "
            "file_replace_many (cambios puntuales) o file_write (reescritura). "
            "No expliques ni pidas permiso: arregla y el sistema volverá a probar solo. "
            "No quites funcionalidad para esquivar el error. "
            "Si el fallo se debe a una variable de entorno, API key o servicio externo "
            "que no existe en el sandbox, no es un bug: no inventes valores."
        )
        return "\n".join(parts)

    def success_note(self, attempts_used: int) -> str:
        n = sum(1 for c in self.checks if c.ok)
        txt = f"✅ Probado en sandbox ({n} comprobaciones OK"
        txt += f", {attempts_used} correcciones automáticas)" if attempts_used else ")"
        return txt

    def inconclusive_note(self) -> str:
        why = [c.note or c.name for c in self.checks if c.inconclusive]
        if not self.sandbox_used:
            why = self.notes or ["sandbox no disponible; solo se validó la sintaxis"]
        return "⚠️ No pude verificarlo del todo: " + "; ".join(why)


def _tail(text: str, limit: int = TAIL_CHARS) -> str:
    text = text.strip()
    return text if len(text) <= limit else "[...]\n" + text[-limit:]


# ======================================================================
# Estado por turno
# ======================================================================

@dataclass
class LoopState:
    workspace: Path
    max_attempts: int = 8
    written: dict[str, None] = field(default_factory=dict)   # conjunto ordenado
    dirty: bool = False
    attempts: int = 0                                         # verificaciones fallidas
    sig_counts: dict[str, int] = field(default_factory=dict)
    last_report: VerifyReport | None = None

    def pending(self) -> bool:
        return bool(self.written)

    def mark_written(self, path: str) -> None:
        p = Path(path)
        if p.is_absolute():
            try:
                p = p.relative_to(self.workspace)
            except ValueError:
                return
        if p.suffix.lower() in VERIFIABLE_EXT:
            self.written[str(p)] = None
            self.dirty = True

    def register_failure(self, report: VerifyReport) -> int:
        self.attempts += 1
        sig = report.signature
        self.sig_counts[sig] = self.sig_counts.get(sig, 0) + 1
        self.last_report = report
        return self.sig_counts[sig]

    def exhausted(self) -> bool:
        return (
            self.attempts >= self.max_attempts
            or any(n >= SAME_ERROR_LIMIT for n in self.sig_counts.values())
        )

    def giveup_text(self, report: VerifyReport) -> str:
        c = report.failed
        why = (
            "el mismo error se repitió 3 veces"
            if any(n >= SAME_ERROR_LIMIT for n in self.sig_counts.values())
            else f"agoté los {self.max_attempts} intentos"
        )
        combined_output = "\n".join(part for part in (c.stdout, c.stderr) if part) if c else ""
        err = _tail(combined_output or "(sin salida)", 6000)
        return (
            f"\n\n❌ No logré dejarlo funcionando: {why}.\n"
            f"Último error ({c.name if c else '?'}):\n{err}"
        )

    def track(self, tool_name: str, args: dict[str, Any], result: Any) -> None:
        """Registra qué archivos de código tocó una herramienta."""
        if not isinstance(result, dict) or result.get("error"):
            return
        if tool_name in ("file_write", "file_append"):
            if result.get("path"):
                self.mark_written(result["path"])
        elif tool_name == "file_replace_many":
            if result.get("changed") and result.get("path"):
                self.mark_written(result["path"])


@dataclass
class Gate:
    """Decisión de la compuerta cuando el modelo quiere dar su respuesta final."""
    action: str      # "skip" | "pass" | "retry" | "giveup"
    message: str = ""  # retry: mensaje para el modelo · pass/giveup: texto a añadir a la respuesta


# ======================================================================
# Verificador
# ======================================================================

class CodeLoop:
    def __init__(
        self,
        executor_factory: Callable[[], Executor | None],
        run_timeout: int = 20,
        remote_root: str = REMOTE_ROOT,
    ) -> None:
        self.executor_factory = executor_factory
        self.run_timeout = run_timeout
        self.remote_root = remote_root

    # ---------------- API pública ----------------

    async def gate(self, st: LoopState) -> Gate:
        """Se llama cuando el modelo ya no pide más herramientas."""
        if not st.pending():
            return Gate("skip")
        report = await self.verify(st)
        if report.status == "fail":
            repeated = st.register_failure(report)
            if st.exhausted():
                return Gate("giveup", st.giveup_text(report))
            return Gate("retry", report.feedback(st.attempts, st.max_attempts, repeated))
        st.written.clear()   # verificado: el bucle se rompe
        if report.status == "ok":
            return Gate("pass", "\n\n" + report.success_note(st.attempts))
        return Gate("pass", "\n\n" + report.inconclusive_note())

    async def verify(self, st: LoopState) -> VerifyReport:
        if not st.dirty and st.last_report is not None and st.last_report.failed:
            st.last_report.reused = True
            return st.last_report

        report = VerifyReport()
        files = {
            rel: st.workspace / rel
            for rel in st.written
            if (st.workspace / rel).is_file()
        }
        st.dirty = False
        if not files:
            report.notes.append("no hay archivos de código que verificar")
            return report

        # 1) Estático, local, gratis
        for rel, path in files.items():
            err = self._static_check(rel, path)
            if err:
                report.checks.append(Check(name=f"sintaxis {rel}", ok=False, returncode=1, stderr=err))
        if report.failed:
            report.notes.append("falló el chequeo estático; no se gastó sandbox")
            return report
        for rel in files:
            report.checks.append(Check(name=f"sintaxis {rel}", ok=True))

        runnable = [r for r in files if Path(r).suffix.lower() in {".py", ".js", ".mjs"}]
        if not runnable:
            report.notes.append("solo había archivos de datos; se validó el formato")
            return report

        # 2) Sandbox
        try:
            ex = self.executor_factory()
        except Exception as exc:  # p. ej. falta E2B_API_KEY
            ex = None
            report.notes.append(f"sandbox no disponible ({exc})")
        if ex is None:
            if not report.notes:
                report.notes.append("sandbox no configurado")
            return report

        try:
            project = self._collect_project(files, st.workspace)
            await ex.put_files({rel: p.read_bytes() for rel, p in project.items()})
            report.sandbox_used = True
            await self._run_checks(ex, report, files, project)
        except Exception as exc:
            report.sandbox_used = False
            report.notes.append(f"error hablando con el sandbox: {type(exc).__name__}: {exc}")
        return report

    # ---------------- internos ----------------

    @staticmethod
    def _static_check(rel: str, path: Path) -> str:
        ext = path.suffix.lower()
        try:
            text = path.read_text(encoding="utf-8")
        except Exception as exc:
            return f"{rel}: no se pudo leer ({exc})"
        if ext == ".py":
            try:
                ast.parse(text, filename=rel)
            except SyntaxError as exc:
                line = (exc.text or "").rstrip("\n")
                caret = " " * max((exc.offset or 1) - 1, 0) + "^"
                return f"SyntaxError en {rel}, línea {exc.lineno}: {exc.msg}\n    {line}\n    {caret}"
        elif ext == ".json":
            try:
                json.loads(text)
            except json.JSONDecodeError as exc:
                return f"JSON inválido en {rel}, línea {exc.lineno}, col {exc.colno}: {exc.msg}"
        return ""

    def _collect_project(self, written: dict[str, Path], ws: Path) -> dict[str, Path]:
        """Los archivos escritos + los del mismo proyecto (para imports/tests)."""
        out: dict[str, Path] = dict(written)
        roots: set[str | None] = {
            (Path(rel).parts[0] if len(Path(rel).parts) > 1 else None) for rel in written
        }
        for root in roots:
            if root is None:
                candidates = [p for p in ws.iterdir() if p.is_file()]
            else:
                candidates = [p for p in (ws / root).rglob("*") if p.is_file()]
            for p in candidates:
                if len(out) >= MAX_SYNC_FILES:
                    break
                rel_parts = p.relative_to(ws).parts
                if any(part in SKIP_DIRS for part in rel_parts):
                    continue
                try:
                    if p.stat().st_size > MAX_SYNC_BYTES:
                        continue
                except OSError:
                    continue
                out.setdefault(str(p.relative_to(ws)), p)
        return out

    async def _exec(self, ex: Executor, cmd: str, cwd: str, timeout: float) -> dict[str, Any]:
        full = (
            f"cd {shlex.quote(cwd)} && export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 && {cmd}"
        )
        r = await ex.run(full, timeout)
        return {
            "rc": r.get("returncode", -1 if not r.get("ok") else 0),
            "stdout": r.get("stdout", "") or "",
            "stderr": r.get("stderr", "") or "",
            "error": r.get("error"),
        }

    def _cwd(self, rel_dir: str) -> str:
        return f"{self.remote_root}/{rel_dir}".rstrip("/") if rel_dir not in ("", ".") else self.remote_root

    async def _run_checks(
        self, ex: Executor, report: VerifyReport,
        written: dict[str, Path], project: dict[str, Path],
    ) -> None:
        t = self.run_timeout
        py_written = [r for r in written if r.endswith(".py")]
        js_written = [r for r in written if r.endswith((".js", ".mjs"))]
        local_modules = {Path(r).stem for r in project if r.endswith(".py")}

        # --- dependencias ---
        if py_written and "requirements.txt" in project:
            r = await self._exec(ex, "python -m pip install -q -r requirements.txt", self.remote_root, 300)
            report.checks.append(Check(
                "instalar requirements.txt", r["rc"] == 0,
                "pip install -r requirements.txt", r["rc"], r["stdout"], r["stderr"],
            ))
            if r["rc"] != 0:
                return
        if js_written and "package.json" in project:
            r = await self._exec(ex, "npm install --no-audit --no-fund --silent", self.remote_root, 300)
            report.checks.append(Check(
                "npm install", r["rc"] == 0, "npm install", r["rc"], r["stdout"], r["stderr"],
            ))
            if r["rc"] != 0:
                return

        # --- Python ---
        if py_written:
            test_files = [
                r for r in project
                if r.endswith(".py") and (Path(r).name.startswith("test_") or Path(r).name.endswith("_test.py"))
            ]
            if test_files:
                await self._pytest(ex, report)
            else:
                for rel in self._pick_entries(py_written, written):
                    await self._run_script(ex, report, rel, local_modules)
                    if report.failed:
                        return
            if report.failed:
                return

        # --- JavaScript ---
        for rel in js_written:
            cwd = self._cwd(str(Path(rel).parent))
            name = Path(rel).name
            r = await self._exec(ex, f"node --check {shlex.quote(name)}", cwd, 30)
            report.checks.append(Check(
                f"node --check {rel}", r["rc"] == 0, f"node --check {name}", r["rc"], r["stdout"], r["stderr"],
            ))
            if r["rc"] != 0:
                return
        for rel in self._pick_entries(js_written, written):
            await self._run_script(ex, report, rel, set(), kind="node")
            if report.failed:
                return

    @staticmethod
    def _pick_entries(candidates: list[str], written: dict[str, Path]) -> list[str]:
        """Si se tocaron muchos archivos, probar solo los puntos de entrada."""
        if len(candidates) <= 3:
            return candidates
        entries = []
        for rel in candidates:
            stem = Path(rel).stem
            try:
                has_main = "__main__" in written[rel].read_text(encoding="utf-8", errors="ignore")
            except Exception:
                has_main = False
            if stem in ENTRY_NAMES or has_main:
                entries.append(rel)
        return entries[:5] or candidates[:3]

    async def _pytest(self, ex: Executor, report: VerifyReport) -> None:
        await self._exec(
            ex, "python -m pytest --version >/dev/null 2>&1 || python -m pip install -q pytest",
            self.remote_root, 180,
        )
        cmd = "python -m pytest -x -q --no-header -p no:cacheprovider"
        r = await self._exec(ex, cmd, self.remote_root, max(self.run_timeout * 3, 90))
        ok = r["rc"] in (0, 5)   # 5 = no se recogió ningún test
        c = Check("pytest", ok, cmd, r["rc"], r["stdout"], r["stderr"] or (r["stdout"] if not ok else ""))
        out = r["stdout"] + r["stderr"]
        if not ok and "No module named pytest" in out:
            c.ok, c.inconclusive = False, True
            c.note = "no se pudo instalar pytest en el sandbox, los tests no se ejecutaron"
        elif not ok and _ENV_ERROR.search(out):
            c.ok, c.inconclusive = False, True
            c.note = "los tests necesitan una variable de entorno o servicio externo que el sandbox no tiene"
        report.checks.append(c)

    async def _run_script(
        self, ex: Executor, report: VerifyReport, rel: str,
        local_modules: set[str], kind: str = "python",
    ) -> None:
        name = Path(rel).name
        cwd = self._cwd(str(Path(rel).parent))
        t = self.run_timeout
        interp = "python" if kind == "python" else "node"
        cmd = f"timeout {t} {interp} {shlex.quote(name)} < /dev/null"
        installed: list[str] = []
        r: dict[str, Any] = {"rc": 0, "stdout": "", "stderr": ""}

        for _ in range(4):   # reintentos solo para instalar dependencias que faltan
            r = await self._exec(ex, cmd, cwd, t + 60)
            if r["rc"] in (0, 124):
                break
            missing = self._missing_module(r["stderr"], kind)
            if not missing or missing in local_modules:
                break
            # Los paquetes Node deben declararse en package.json y se instalan
            # en el paso de dependencias; no se adivinan ni se descargan aquí.
            if kind != "python":
                break
            pkg = PIP_NAMES.get(missing)
            if not pkg:
                # Devuelve el ModuleNotFoundError exacto al modelo para que
                # añada una dependencia explícita o corrija un import local.
                break
            install = f"python -m pip install -q {shlex.quote(pkg)}"
            ins = await self._exec(ex, install, self.remote_root if kind == "node" else cwd, 180)
            if ins["rc"] != 0:
                r["stderr"] += f"\n[auto-instalación de '{pkg}' falló: {ins['stderr'][-300:]}]"
                break
            installed.append(pkg)

        out = r["stdout"] + r["stderr"]
        ok = r["rc"] in (0, 124)
        note = ""
        if r["rc"] == 124:
            note = f"siguió ejecutándose {t}s sin fallar (normal en servidores/bots)"
        if not ok and "EOFError" in out and "input(" in (r.get("stderr", "")):
            ok, note = True, "pide datos por teclado (EOF esperado)"
        c = Check(f"ejecutar {rel}", ok, f"{interp} {name}", r["rc"], r["stdout"], r["stderr"], note=note)
        if not ok and _ENV_ERROR.search(out):
            c.inconclusive = True
            c.note = f"{rel} necesita una variable de entorno o servicio externo que el sandbox no tiene"
        if installed:
            report.notes.append("dependencias instaladas automáticamente: " + ", ".join(installed))
        report.checks.append(c)

    @staticmethod
    def _missing_module(stderr: str, kind: str) -> str | None:
        if kind == "python":
            m = re.search(r"No module named '([\w\.\-]+)'", stderr)
            return m.group(1).split(".")[0] if m else None
        m = re.search(r"Cannot find module '([^'./][^']*)'", stderr)   # ignora rutas relativas
        return m.group(1) if m else None
