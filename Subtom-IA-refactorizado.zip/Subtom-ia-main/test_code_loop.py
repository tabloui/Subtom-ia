"""
Tests del bucle verificar→corregir. No necesitan E2B ni red:
usan un ejecutor local (subprocess en un directorio temporal).

    python test_code_loop.py
"""
from __future__ import annotations

import asyncio
import shutil
import tempfile
from pathlib import Path

from code_loop import CodeLoop, LoopState


class LocalExecutor:
    """Misma interfaz que SandboxExecutor, pero en un tmpdir local."""

    def __init__(self, root: Path) -> None:
        self.root = root

    async def put_files(self, files):
        shutil.rmtree(self.root, ignore_errors=True)
        for rel, data in files.items():
            p = self.root / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)

    async def run(self, command, timeout):
        proc = await asyncio.create_subprocess_shell(
            command, executable="/bin/bash",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        out, err = await asyncio.wait_for(proc.communicate(), timeout)
        return {
            "ok": proc.returncode == 0, "returncode": proc.returncode,
            "stdout": out.decode(errors="replace"), "stderr": err.decode(errors="replace"),
        }


def make_env():
    tmp = Path(tempfile.mkdtemp())
    ws, remote = tmp / "workspace", tmp / "remote"
    ws.mkdir()
    loop = CodeLoop(lambda: LocalExecutor(remote), run_timeout=3, remote_root=str(remote))
    return ws, loop


def write(ws: Path, st: LoopState, name: str, content: str) -> None:
    """Imita lo que hace file_write + st.track()."""
    p = ws / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    st.track("file_write", {}, {"path": str(p)})


async def drive(ws, loop, st, attempts_script):
    """
    Simula ai.py: el 'modelo' escribe la siguiente versión del archivo,
    la compuerta la prueba, y si falla el error vuelve al modelo.
    """
    log = []
    for version in attempts_script:
        write(ws, st, "app.py", version)
        g = await loop.gate(st)
        log.append(g)
        if g.action != "retry":
            break
    return log


# ----------------------------------------------------------------------

async def test_bucle_corrige_y_se_rompe():
    ws, loop = make_env()
    st = LoopState(workspace=ws, max_attempts=8)
    script = [
        "def suma(a, b)\n    return a + b\n",                         # 1) error de sintaxis
        "def suma(a, b):\n    return a + b\nprint(suma(1))\n",        # 2) TypeError en ejecución
        "def suma(a, b):\n    return a + b\nprint(suma(1, 2))\n",     # 3) correcto
    ]
    log = await drive(ws, loop, st, script)
    assert [g.action for g in log] == ["retry", "retry", "pass"], [g.action for g in log]
    assert "SyntaxError" in log[0].message and "línea 1" in log[0].message
    assert "TypeError" in log[1].message
    assert "✅" in log[2].message and "2 correcciones" in log[2].message
    assert not st.pending()
    print("OK  bucle: sintaxis → runtime → correcto → se rompe")


async def test_no_bucle_infinito_mismo_error():
    ws, loop = make_env()
    st = LoopState(workspace=ws, max_attempts=8)
    bug = "x = 1 / 0\n"
    log = await drive(ws, loop, st, [bug, bug + "# intento 2\n", bug + "# intento 3\n", bug + "# 4\n"])
    assert [g.action for g in log] == ["retry", "retry", "giveup"], [g.action for g in log]
    assert "MISMO error" in log[1].message
    assert "ZeroDivisionError" in log[2].message
    print("OK  mismo error 3 veces → se rinde y lo dice")


async def test_tope_de_intentos():
    ws, loop = make_env()
    st = LoopState(workspace=ws, max_attempts=2)
    log = await drive(ws, loop, st, ["raise ValueError('a')\n", "raise KeyError('b')\n", "raise OSError('c')\n"])
    assert [g.action for g in log] == ["retry", "giveup"], [g.action for g in log]
    print("OK  tope de intentos respetado")


async def test_sin_cambios_no_gasta_sandbox():
    ws, loop = make_env()
    st = LoopState(workspace=ws)
    write(ws, st, "app.py", "raise RuntimeError('boom')\n")
    g1 = await loop.gate(st)
    g2 = await loop.gate(st)   # el modelo no tocó nada
    assert g1.action == "retry" and g2.action == "retry"
    assert "No modificaste ningún archivo" in g2.message
    print("OK  sin cambios → no re-ejecuta, avisa al modelo")


async def test_servidor_que_no_termina_es_ok():
    ws, loop = make_env()
    st = LoopState(workspace=ws)
    write(ws, st, "server.py", "import time\nwhile True:\n    time.sleep(1)\n")
    g = await loop.gate(st)
    assert g.action == "pass" and "✅" in g.message, g
    print("OK  proceso que sigue vivo (servidor/bot) cuenta como OK")


async def test_error_de_entorno_no_se_persigue():
    ws, loop = make_env()
    st = LoopState(workspace=ws)
    write(ws, st, "bot.py", "import os\nraise RuntimeError('Falta la variable DISCORD_BOT_TOKEN')\n")
    g = await loop.gate(st)
    assert g.action == "pass" and "⚠️" in g.message and "variable de entorno" in g.message, g
    print("OK  falta de API key → aviso, no bucle")


async def test_pytest_se_usa_si_hay_tests():
    ws, loop = make_env()
    st = LoopState(workspace=ws)
    write(ws, st, "calc.py", "def dobla(x):\n    return x + x + 1\n")
    write(ws, st, "test_calc.py", "from calc import dobla\ndef test_d():\n    assert dobla(2) == 4\n")
    g = await loop.gate(st)
    if g.action == "pass" and "pytest" in g.message:
        print("OK  pytest no instalable → 'no concluyente' con aviso (no se culpa al código)")
        return
    assert g.action == "retry" and "pytest" in g.message and "assert" in g.message.lower(), g.message
    write(ws, st, "calc.py", "def dobla(x):\n    return x * 2\n")
    g = await loop.gate(st)
    assert g.action == "pass", g.message
    print("OK  pytest: test falla → se corrige → pasa")


async def test_import_local_roto_es_bug_real():
    ws, loop = make_env()
    st = LoopState(workspace=ws)
    write(ws, st, "main.py", "import utilidades\nprint(utilidades.f())\n")
    g = await loop.gate(st)
    assert g.action == "retry" and "ModuleNotFoundError" in g.message, g.message
    write(ws, st, "utilidades.py", "def f():\n    return 42\n")
    g = await loop.gate(st)
    assert g.action == "pass", g.message
    print("OK  import de módulo local inexistente → bug real → se corrige")


async def test_json_invalido_y_sin_sandbox():
    ws, _ = make_env()
    loop = CodeLoop(lambda: None)           # sin sandbox configurado
    st = LoopState(workspace=ws)
    write(ws, st, "data.json", '{"a": 1,}')
    g = await loop.gate(st)
    assert g.action == "retry" and "JSON inválido" in g.message
    write(ws, st, "data.json", '{"a": 1}')
    write(ws, st, "x.py", "print('hola')\n")
    g = await loop.gate(st)
    assert g.action == "pass" and "⚠️" in g.message and "sandbox" in g.message, g
    print("OK  JSON roto detectado; sin sandbox degrada a solo estático con aviso")


async def main():
    for t in (
        test_bucle_corrige_y_se_rompe, test_no_bucle_infinito_mismo_error,
        test_tope_de_intentos, test_sin_cambios_no_gasta_sandbox,
        test_servidor_que_no_termina_es_ok, test_error_de_entorno_no_se_persigue,
        test_pytest_se_usa_si_hay_tests, test_import_local_roto_es_bug_real,
        test_json_invalido_y_sin_sandbox,
    ):
        await t()
    print("\nTODOS LOS TESTS DEL BUCLE PASARON")


if __name__ == "__main__":
    asyncio.run(main())
